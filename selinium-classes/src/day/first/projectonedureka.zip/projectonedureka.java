package day.first;

public class projectonedureka {

}
